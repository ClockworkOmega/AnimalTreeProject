#include <iostream>
#include <algorithm>
#include <string>
#include <vector>
#include <cassert>
#include "DLinkedList.h"
#include "Stack.h"
#include "Deque.h"

using namespace std;

void puzzleGame();

int main()
{
  // Start the puzzle game
	puzzleGame();

	return 0;
}

void puzzleGame()
{
	cout << "Welcome to the puzzle grid!\n\n";

	// Create a DLinkedList called planets
	// And then create fourteen numbered nodes

	DLinkedList planets;
	planets.addFront("1");
	planets.addBack("2");
	planets.addBack("3");
	planets.addBack("4");
	planets.addBack("5");
	planets.addBack("6");
	planets.addBack("7");
	planets.addBack("8");
	planets.addBack("9");
	planets.addBack("10");
	planets.addBack("11");
	planets.addBack("12");
	planets.addBack("13");
	planets.addBack("14");

	// Initialize variables and create 
	// a menu for the game using switch statements.
	int menuChoice = 0;
	int nodeNumber;
	char charInput;
	const int EXIT_NUM = 4;

	while (menuChoice != EXIT_NUM)
	{
		cout << " 1 - Insert Node\n";
		cout << " 2 - Remove Node\n";
		cout << " 3 - Print Game\n";
		cout << " 4 - Exit\n\n";

		cout << "Please input your desired option: ";
		cin >> menuChoice;
		cout << endl << endl;

		switch (menuChoice)
		{
		case 1:
     // Case 1 allows the user to insert a character
     // at the number node of their choice
   
			cout << "Type in the node NUMBER would you like to change: ";
			cin >> nodeNumber;
      
			cout << endl << endl;

			cout << "Type in your CHARACTER input: ";
			cin >> charInput;

			planets.insert(nodeNumber, charInput);
			cout << endl << endl;
			break;

    
		case 2:
     // Case 2 allows a user to remove a character
     // from the number node of their chouce
     
			cout << "Type in the node NUMBER would you like to remove: ";
			cin >> nodeNumber;

			planets.remove(nodeNumber);
			cout << endl << endl;
			break;

		case 3:
			// Case 3 prints the crossword for the user

			cout << "----------------------------------\n\n";

			cout << "Current Game State: \n";

			cout << "          - " << endl;
			cout << "        | " << planets.print(1) << " | " << endl;
			cout << "          -   " << endl;
			cout << "        | " << planets.print(2) << " | " << endl;
			cout << "  -   -   -   - " << endl;
			cout << "| " << planets.print(6) << " | " << planets.print(7) 
				 << " | " << planets.print(3) << " | " << planets.print(8) << " |" << endl;
			cout << "  -   -   -   -  " << endl;
			cout << "| " << planets.print(9) << " |   | " << planets.print(4) << " |    " << endl;
			cout << "  -       -   " << endl;
			cout << "| " << planets.print(10) << " |  | " << planets.print(5) << " | " << endl;
			cout << "  -       -   " << endl;
			cout << "| " << planets.print(11) << " | " << endl;
			cout << "  -   " << endl;
			cout << "| " << planets.print(12) << " | " << endl;
			cout << "  -   " << endl;
			cout << "| " << planets.print(13) << " | " << endl;
			cout << "  -   " << endl;
			cout << "| " << planets.print(14) << " | " << endl;
			cout << "  -   " << endl;

			cout << endl << endl;

			cout << "----------------------------------\n\n";

			break;
      
		case 4:
    // Case 4 ends the puzzle
			break;
		}
	}
}