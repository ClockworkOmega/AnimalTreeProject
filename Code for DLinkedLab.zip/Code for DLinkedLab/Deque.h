#pragma once

#include "DLinkedList.h"

class Deque : public DLinkedList
{
public:
	Deque() { size_ = 0; }
	~Deque() {};

	void enqueue_front(const Elem& e);
	void enqueue_back(const Elem& e);
	void dequeue_front();
	void dequeue_back();
	void Front();
	void Back();
	int Size();
	bool Empty();

private:
	int size_;
};