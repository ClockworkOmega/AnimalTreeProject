#include <iostream>
#include "DLinkedList.h"

using namespace std;

// Function to see if the list is empty or not
bool DLinkedList::empty() const 
{
	if (header_->next == trailer_)
		return false;
	else
		return true;
}

// Function to return the size of the list
int DLinkedList::size()
{
	return size_;
}

// Function to return the value 
// of the first node in the list
const Elem& DLinkedList::front() const
{
	return header_->value;
}

// Function to return the value 
// of the last node in the list
const Elem& DLinkedList::back() const
{
	return trailer_->value;
}

// Function to add a new node to the front of the list
void DLinkedList::addFront(const Elem& content)
{
	// If there is no header
	// create a temporary node and set
	// the header to it
	if (header_ == NULL)
	{
		header_ = new(struct DNode);
		header_->prev = NULL;
		header_->value = content;
		header_->next = NULL;
		header_->originalVal = 1;

		trailer_ = header_;
		++size_;
	}
	else
	{
		//Create temp node to be the new header
		
		DNode *tmp;
		tmp = new(struct DNode);
		tmp->prev = NULL;
		tmp->value = content;
		tmp->next = header_;

		header_->prev = tmp;
		header_ = tmp;
		++size_;
	}
}

// Function to add a new node to the back of the list
void DLinkedList::addBack(const Elem& e)
{
	// If there is no header
	// create a temporary node and set
	// the header to it
	if (trailer_ == NULL)
	{
		trailer_ = new(struct DNode);
		trailer_->prev = NULL;
		trailer_->value = e;
		trailer_->next = NULL;
		trailer_->originalVal = 1;

		trailer_ = header_;
		++size_;
	}
	else
	{
		//Create a temp node to be the new header
		DNode *tmp;
		tmp = new(struct DNode);
		tmp->prev = trailer_;
		tmp->value = e;
		tmp->next = NULL;
		tmp->originalVal = size() + 1;

		trailer_->next = tmp;
		trailer_ = tmp;
		++size_;
	}
}

//Function to remove the first node in a list
void DLinkedList::removeFront()
{
	// Check to see if there is anything
	// in the list first
	if (header_ == NULL)
	{
		cout << "Create a doubly linked list first.";
	}

	// Check to see if the list has more than one item.
	// If it only has one node erase it.
	if (header_->next == NULL)
	{
		delete header_;
		--size_;
	}
	else
	{
		DNode* next = header_->next;
		delete header_;
		header_ = next;
		header_->prev = NULL;
		header_->originalVal = 1;
		--size_;
	}
}

// Function to remove the last node in the list
void DLinkedList::removeBack()
{
	// Check to see if there is anything
	// in the list first
	if (header_ == NULL)
	{
		cout << "Create a doubly linked list first.";
	}

	// Check to see if the list has more than one item.
	// If it only has one node erase it.
	if (trailer_->prev == NULL)
	{
		delete trailer_;
		--size_;
	}
	else
	{
		DNode* prev = trailer_->prev;
		delete trailer_;
		trailer_ = prev;
		trailer_->next = NULL;
		--size_;
	}
	
}

// Function to print the value of a node in the DLinkedList
const Elem& DLinkedList::print(int nodeVal)
{
	DNode *current;
	current = header_;

	while (current->originalVal != nodeVal && current != NULL)
	{
		current = current->next;
	}

	return current->value;
}

// Function to insert a node into the DLinkedList
void DLinkedList::insert(int nodeNum, char userChar)
{
	DNode *current;
	current = header_;

	while (current->originalVal != nodeNum && current != NULL)
	{
		current = current->next;
	}

	current->value = userChar;
}

// Function to remove an item from the DLinkedList
// by using it node number
void DLinkedList::remove(int nodeNum)
{
	DNode *current;
	current = header_;
	int ASCII_OFFSET = 48;

	while (current->originalVal != nodeNum && current != NULL)
	{
		current = current->next;
	}

	current->value = (char)nodeNum + ASCII_OFFSET;
}