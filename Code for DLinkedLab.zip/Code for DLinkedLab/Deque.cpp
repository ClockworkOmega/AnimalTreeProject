#include <iostream>
#include <string>
#include "DLinkedList.h"
#include "Deque.h"

using namespace std;

// Function to insert a value
// at the front of the double sided queue
void Deque::enqueue_front(const Elem& e)
{
	addFront(e);
	++size_;
}

// Function to insert a value
// at the back of the double sided queue
void Deque::enqueue_back(const Elem& e)
{
	addBack(e);
	++size_;
}

// Function to return the first value
// in the double sided queue. It also
// removes the value as well.
void Deque::dequeue_front()
{
	front();
	removeFront();
	--size_;
}

// Function to return the last value
// in the double sided queue. It also
// removes the value as well.
void Deque::dequeue_back()
{
	back();
	removeBack();
	--size_;
}

// Function to show the first value
// in the double sided queue
void Deque::Front()
{
	front();
}

// Function to show the last value
// in the double sided queue
void Deque::Back()
{
	back();
}

// Function to show the size
// of the double sided queue
int Deque::Size()
{
	return size_;
}

// Function to see if it is empty
bool Deque::Empty()
{
	if (size_ == 0)
		return true;
	else
		return false;
}