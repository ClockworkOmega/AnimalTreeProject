#pragma once

#include <string>
using namespace std;

typedef string Elem;

struct DNode
{ 
	int originalVal;
	Elem value;
	DNode* next;
	DNode* prev;
};

class DLinkedList
{
public:
	DLinkedList() { header_ = NULL; size_ = 0;}
	~DLinkedList() { };
	bool empty() const;
	int size();
	const Elem& front() const;
	const Elem& back() const;
	void addFront(const Elem& e);
	void addBack(const Elem& e);
	void removeFront();
	void removeBack();
	const Elem& print(int nodeVal);
	void insert(int nodeNum, char userChar);
	void remove(int nodeNum);

private:
	DNode* header_;
	DNode* trailer_;
	int size_;
	
};
