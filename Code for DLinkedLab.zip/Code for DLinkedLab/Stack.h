#pragma once

#include "DLinkedList.h"

class Stack : public DLinkedList
{
public:
	Stack() { size_ = 0; };
	~Stack() {};

	int size();
	bool empty();
	void push(const Elem& e);
	const Elem& top() const;
	void pop();
	

private:
	int size_;
};
