#include <iostream>
#include <string>
#include "DLinkedList.h"
#include "Stack.h"

using namespace std;

// Return the size of the stack
int Stack::size() 
{ 
	return size_; 
}

// Push an item onto the stack
void Stack::push(const Elem& e)
{ 
	addFront(e); 
	++size_; 
}

// Check to see if the stack is empty
bool Stack::empty()
{
	if (size_ == 0)
	{
		return true;
	}
	else
	{
		return false;
	}
}

// Print the first item on the stack
const Elem& Stack::top() const
{
		return front();
}

// Remove the first item on the stack
void Stack::pop()
{
	if (size_ == 0)
	{
		cout << "The stack is empty." << endl;
	}
	else
	{
		removeFront();
		--size_;
	}
}
